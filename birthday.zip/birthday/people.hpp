#include <iostream>
using namespace std;
#include "birthday.hpp"

class People
{
    public:
      People(string x, Birthday bo);
      void printInfo();
    private:
      string name;
      Birthday dateOfBirth;
};

People::People(string x, Birthday bo)
: name(x), dateOfBirth(bo)
{
    
}

void People::printInfo(){
    cout<<name<<"was born on";
    dateOfBirth.printDate();
}
