#include "birthday.hpp"
#include "people.hpp"

int main()
{
    Birthday birthObj(8,28,1985);

    //birthObj.printDate();

    People Dileep("DIleep the King",birthObj);

    Dileep.printInfo(); 
   
    return 0;
}